# Task 1 – WhatsApp Business Group Connector  
**Connector Challenge 2026 · Equip9 / E9Rental.ai**

Complete, official-API-only solution for Task 1.

## What it does

1. Exposes a public HTTPS-compatible webhook (`/webhook`) that receives **official WhatsApp Cloud API** payloads.
2. Processes **only** the groups listed in `config/selected_groups.json`.  
   Every other group is ignored completely (no storage, no logging, no analysis).
3. For each selected group produces:
   - Group name + full participant list (name + WA ID)
   - Every message with sender and timestamp
   - An interpretation: short summary, what each participant is asking for / committing to, action items and decisions
4. Writes the final structured result to `outputs/whatsapp_output.json`.

## Project layout

```
whatsapp_connector/
├── config/
│   └── selected_groups.json      # Only these groups are ever processed
├── src/
│   ├── webhook.py                # Flask webhook server (Cloud API)
│   ├── storage.py                # In-memory store + JSON persistence
│   ├── interpreter.py            # Conversation interpretation engine
│   └── simulate_replay.py        # Simulates organiser history replay + live messages
├── outputs/
│   └── whatsapp_output.json      # Final deliverable
├── .env.example
├── requirements.txt
└── README.md
```

## Quick start (local demo – 100 % offline)

```bash
# 1. Install
cd whatsapp_connector
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# 2. Start the webhook server (terminal 1)
python src/webhook.py

# 3. Run the organiser-style history replay + live messages (terminal 2)
python src/simulate_replay.py
```

After the simulation finishes you will have a complete `outputs/whatsapp_output.json`.

## Real event usage

1. Put your public HTTPS URL (ngrok / Cloudflare Tunnel) into the organiser’s setup desk form.
2. Set the environment variables from `.env.example`.
3. Start the server: `python src/webhook.py` (or use gunicorn).
4. At 10:00 the organiser will POST the history replay to your `/webhook`.  
   Live messages continue throughout the day.
5. When you are ready to freeze the output, call:

```bash
curl -X POST http://localhost:5000/generate
```

This runs the interpreter and writes `outputs/whatsapp_output.json`.

## Security & rules compliance

- Only official Cloud API webhook format is accepted.
- Only `gmail.readonly` / `drive.readonly` style discipline is followed here: **read-only**.
- No unofficial libraries (no whatsapp-web.js, Baileys, Selenium, etc.).
- Secrets never committed – only `.env.example` is present.
- Groups outside `selected_groups.json` are discarded at the earliest possible point.

## AI usage

See `AI_USAGE.md`.

## Architecture (short)

```
WhatsApp Cloud API ──POST──► /webhook
                              │
                              ▼
                     selected_groups filter
                              │
                              ▼
                          storage.py
                              │
                              ▼
                     interpreter.py (on /generate)
                              │
                              ▼
                  outputs/whatsapp_output.json
```
