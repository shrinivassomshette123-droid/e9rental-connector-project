# AI Usage – Task 1 WhatsApp Connector

AI tools were used only for:

- Drafting the initial project skeleton and file layout
- Suggesting clean structure for the webhook payload parser
- Helping write clear docstrings and README text

All final code was reviewed, tested and owned by the team.  
Every team member can explain every line of the connector, the storage layer and the interpretation heuristics.
