"""
Simulates the exact behaviour the organiser performs at 10:00:
  - Replays each selected group's history to the webhook
  - Then continues with a few live messages
This script POSTs official-format Cloud API webhook payloads
to http://localhost:5000/webhook so the full pipeline runs
without needing a real WhatsApp number.
"""

from __future__ import annotations
import json
import time
import requests
from datetime import datetime, timezone, timedelta
from pathlib import Path

BASE = "http://127.0.0.1:8080"
WEBHOOK = f"{BASE}/webhook"

# Synthetic but realistic conversation data matching the challenge theme
REPLAY_DATA = {
    "120363123456789012": {  # Site Team - Pune Project
        "group_name": "Site Team - Pune Project",
        "participants": [
            {"wa_id": "919876543210", "name": "Ravi (Site Engineer)"},
            {"wa_id": "919876543211", "name": "Priya (Project Manager)"},
            {"wa_id": "919876543212", "name": "Amit (Procurement)"},
            {"wa_id": "919876543213", "name": "Suresh (Contractor)"},
        ],
        "messages": [
            {
                "id": "wamid.HBgMOTE5ODc2NTQzMjEwFQIAEhggAAAA1",
                "from": "919876543210",
                "timestamp": "1729123200",  # ~17 Oct 2024
                "text": "Good morning team. Foundation work for Block A is 80% complete. We need 50 bags of cement by tomorrow EOD.",
            },
            {
                "id": "wamid.HBgMOTE5ODc2NTQzMjExFQIAEhggAAAA2",
                "from": "919876543211",
                "timestamp": "1729123500",
                "text": "Thanks Ravi. Amit, can you please arrange the cement delivery? Also share the updated Gantt chart.",
            },
            {
                "id": "wamid.HBgMOTE5ODc2NTQzMjEyFQIAEhggAAAA3",
                "from": "919876543212",
                "timestamp": "1729123800",
                "text": "I will send the PO to the supplier today and share the delivery confirmation by 4 PM.",
            },
            {
                "id": "wamid.HBgMOTE5ODc2NTQzMjEzFQIAEhggAAAA4",
                "from": "919876543213",
                "timestamp": "1729124100",
                "text": "Labour strength is 22 today. We agreed last week that Block B shuttering starts once cement arrives.",
            },
            {
                "id": "wamid.HBgMOTE5ODc2NTQzMjEwFQIAEhggAAAA5",
                "from": "919876543210",
                "timestamp": "1729209600",
                "text": "Cement received this morning. 48 bags. Quality looks good. Starting Block B shuttering tomorrow.",
            },
            {
                "id": "wamid.HBgMOTE5ODc2NTQzMjExFQIAEhggAAAA6",
                "from": "919876543211",
                "timestamp": "1729210000",
                "text": "Great. Decision: we will complete Block B shuttering by Friday. Please update the site diary.",
            },
            {
                "id": "wamid.HBgMOTE5ODc2NTQzMjEyFQIAEhggAAAA7",
                "from": "919876543212",
                "timestamp": "1729210500",
                "text": "Invoice for the cement has been uploaded to the shared Drive folder under Accounts.",
            },
        ],
    },
    "120363987654321098": {  # Sales Coordination
        "group_name": "Sales Coordination",
        "participants": [
            {"wa_id": "919811122233", "name": "Neha (Sales Lead)"},
            {"wa_id": "919811122234", "name": "Vikram (Account Manager)"},
            {"wa_id": "919811122235", "name": "Anjali (BD)"},
        ],
        "messages": [
            {
                "id": "wamid.HBgMOTE5ODExMTIyMjMzFQIAEhggBBBB1",
                "from": "919811122233",
                "timestamp": "1729125000",
                "text": "Client ABC Corp requested a revised quotation for 12 excavators. Need it by EOD today.",
            },
            {
                "id": "wamid.HBgMOTE5ODExMTIyMjM0FQIAEhggBBBB2",
                "from": "919811122234",
                "timestamp": "1729125600",
                "text": "I will prepare the quotation and share it on email by 5 PM. Also attaching the previous rate card.",
            },
            {
                "id": "wamid.HBgMOTE5ODExMTIyMjM1FQIAEhggBBBB3",
                "from": "919811122235",
                "timestamp": "1729126200",
                "text": "Please also check if they need the extended warranty option. Last deal they asked for it.",
            },
            {
                "id": "wamid.HBgMOTE5ODExMTIyMjMzFQIAEhggBBBB4",
                "from": "919811122233",
                "timestamp": "1729212000",
                "text": "Quotation sent. Client replied – they are happy with the numbers. Decision: we go ahead with the 12-unit deal.",
            },
            {
                "id": "wamid.HBgMOTE5ODExMTIyMjM0FQIAEhggBBBB5",
                "from": "919811122234",
                "timestamp": "1729212600",
                "text": "Great. I will send the draft contract tomorrow morning. KYC documents already received.",
            },
        ],
    },
}


def build_payload(group_id: str, group_name: str, messages: list, contacts: list) -> dict:
    """Build an official-looking Cloud API webhook payload."""
    contact_map = {c["wa_id"]: c["name"] for c in contacts}
    wa_messages = []
    wa_contacts = []

    seen = set()
    for m in messages:
        wa_messages.append(
            {
                "from": m["from"],
                "id": m["id"],
                "timestamp": m["timestamp"],
                "type": "text",
                "text": {"body": m["text"]},
                "context": {"group_id": group_id},  # group attribution
            }
        )
        if m["from"] not in seen:
            seen.add(m["from"])
            wa_contacts.append(
                {
                    "wa_id": m["from"],
                    "profile": {"name": contact_map.get(m["from"], m["from"])},
                }
            )

    return {
        "object": "whatsapp_business_account",
        "entry": [
            {
                "id": "WABA_ID_SIMULATED",
                "changes": [
                    {
                        "value": {
                            "messaging_product": "whatsapp",
                            "metadata": {
                                "display_phone_number": "919999999999",
                                "phone_number_id": "PHONE_NUMBER_ID",
                            },
                            "contacts": wa_contacts,
                            "messages": wa_messages,
                        },
                        "field": "messages",
                    }
                ],
            }
        ],
    }


def main():
    print("=== WhatsApp Connector – History Replay Simulation ===")
    print(f"Target webhook: {WEBHOOK}")

    # Health check
    try:
        r = requests.get(f"{BASE}/health", timeout=3)
        print(f"Health: {r.status_code} – {r.json()}")
    except Exception as e:
        print(f"ERROR: Server not reachable at {BASE}. Start it first with: python src/webhook.py")
        raise SystemExit(1)

    # 1. Replay history for each selected group (exactly what organiser does at 10:00)
    for group_id, data in REPLAY_DATA.items():
        print(f"\nReplaying history for group: {data['group_name']} ({group_id})")
        payload = build_payload(group_id, data["group_name"], data["messages"], data["participants"])
        resp = requests.post(WEBHOOK, json=payload, timeout=10)
        print(f"  → {resp.status_code} {resp.json()}")

        # Also inject participants explicitly (organiser may provide via separate payload)
        # We already extracted from contacts, but we ensure they are stored.
        time.sleep(0.3)

    # 2. Simulate a couple of live messages arriving later in the day
    print("\n=== Live messages (simulated) ===")
    live_msg = {
        "object": "whatsapp_business_account",
        "entry": [
            {
                "id": "WABA_ID_SIMULATED",
                "changes": [
                    {
                        "value": {
                            "messaging_product": "whatsapp",
                            "metadata": {
                                "display_phone_number": "919999999999",
                                "phone_number_id": "PHONE_NUMBER_ID",
                            },
                            "contacts": [
                                {"wa_id": "919876543210", "profile": {"name": "Ravi (Site Engineer)"}}
                            ],
                            "messages": [
                                {
                                    "from": "919876543210",
                                    "id": "wamid.HBgMOTE5ODc2NTQzMjEwFQIAEhggLIVE1",
                                    "timestamp": str(int(datetime.now(timezone.utc).timestamp())),
                                    "type": "text",
                                    "text": {"body": "Live update: shuttering material arrived on site. Starting work now."},
                                    "context": {"group_id": "120363123456789012"},
                                }
                            ],
                        },
                        "field": "messages",
                    }
                ],
            }
        ],
    }
    resp = requests.post(WEBHOOK, json=live_msg, timeout=10)
    print(f"Live message → {resp.status_code}")

    # 3. Generate final output
    print("\n=== Generating final output ===")
    resp = requests.post(f"{BASE}/generate", timeout=10)
    print(resp.json())

    print("\nDone. Check outputs/whatsapp_output.json")


if __name__ == "__main__":
    main()