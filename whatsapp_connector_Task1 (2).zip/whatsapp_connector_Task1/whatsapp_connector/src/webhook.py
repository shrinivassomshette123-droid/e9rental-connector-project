from __future__ import annotations
import os
import json
from datetime import datetime, timezone
from flask import Flask, request, jsonify
from dotenv import load_dotenv
from storage import store
from interpreter import interpret_group

load_dotenv()

app = Flask(__name__)

# Verify token (must match what you set in Meta Dashboard)
VERIFY_TOKEN = os.getenv("WHATSAPP_VERIFY_TOKEN", "equip9_connector_challenge_2026")

@app.route("/webhook", methods=["GET"])
def verify():
    """WhatsApp webhook verification (hub.challenge)."""
    mode = request.args.get("hub.mode")
    token = request.args.get("hub.verify_token")
    challenge = request.args.get("hub.challenge")

    if mode == "subscribe" and token == VERIFY_TOKEN:
        return challenge, 200
    return "Forbidden", 403


@app.route("/webhook", methods=["POST"])
def receive():
    """
    Receive Cloud API webhook payloads.
    Official structure: entry[].changes[].value.messages / contacts / metadata
    Group messages arrive with context.group_id
    """
    payload = request.get_json(force=True, silent=True) or {}

    for entry in payload.get("entry", []):
        for change in entry.get("changes", []):
            if change.get("field") != "messages":
                continue

            value = change.get("value", {})
            contacts = {
                c["wa_id"]: c.get("profile", {}).get("name")
                for c in value.get("contacts", [])
            }

            for msg in value.get("messages", []):
                if msg.get("type") != "text":
                    continue

                # Group ID extraction
                context = msg.get("context", {})
                group_id = context.get("group_id") or msg.get("group_id")

                if not group_id:
                    continue

                # Only process selected groups
                if not store.is_selected(group_id):
                    continue

                sender_wa_id = msg.get("from")
                sender_name = contacts.get(sender_wa_id)
                text = msg.get("text", {}).get("body", "")
                timestamp = msg.get("timestamp")
                message_id = msg.get("id")

                # Convert unix timestamp to ISO
                if timestamp and str(timestamp).isdigit():
                    ts = datetime.fromtimestamp(int(timestamp), tz=timezone.utc).isoformat()
                else:
                    ts = timestamp or ""

                store.add_message(
                    group_id=group_id,
                    message_id=message_id,
                    sender_wa_id=sender_wa_id,
                    sender_name=sender_name,
                    text=text,
                    timestamp=ts,
                )

    return jsonify({"status": "ok"}), 200


@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status": "healthy",
        "selected_groups": list(store.selected.keys())
    }), 200


@app.route("/generate", methods=["POST"])
def generate_output():
    """Run interpretation on all stored groups and write the final JSON."""
    for g in store.get_all():
        interpretation = interpret_group(g)
        store.set_interpretation(g["group_id"], interpretation)

    path = store.save_output()
    return jsonify({
        "status": "generated",
        "path": path,
        "groups": len(store.get_all())
    }), 200


@app.route("/status", methods=["GET"])
def status():
    return jsonify({"groups": store.get_all()}), 200


if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    app.run(host=os.getenv("HOST", "0.0.0.0"), port=port, debug=False)