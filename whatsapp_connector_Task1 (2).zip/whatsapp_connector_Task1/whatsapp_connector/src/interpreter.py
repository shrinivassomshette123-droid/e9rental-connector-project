"""
Conversation interpreter for WhatsApp groups.
Produces a short summary, per-participant asks/commits, and action items.
Uses deterministic heuristics + simple NLP-style extraction so it runs offline
with zero external API calls. Fully grounded in the message text.
"""

from __future__ import annotations
from typing import Any, Dict, List
from collections import defaultdict
import re


ACTION_PATTERNS = [
    (r"\b(will|shall|going to|i'?ll)\b.*\b(send|share|prepare|finish|complete|update|call|meet)\b", "commitment"),
    (r"\b(please|kindly|can you|could you|need|required)\b", "request"),
    (r"\b(decision|decided|agreed|approved|finalised|finalized)\b", "decision"),
    (r"\b(deadline|by\s+\d|tomorrow|today|eod|eow)\b", "deadline"),
    (r"\b(invoice|po|purchase order|quotation|quote|contract|kyc)\b", "document"),
]

def _clean(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip())


def interpret_group(group: Dict[str, Any]) -> Dict[str, Any]:
    messages = group.get("messages", [])
    participants = {p["wa_id"]: p.get("name", p["wa_id"]) for p in group.get("participants", [])}

    if not messages:
        return {
            "summary": "No messages received yet.",
            "participant_activity": [],
            "action_items": [],
            "decisions": [],
        }

    # Chronological text
    timeline = []
    for m in messages:
        name = m.get("sender_name") or participants.get(m["sender_wa_id"], m["sender_wa_id"])
        timeline.append(f"[{m['timestamp']}] {name}: {m['text']}")

    # Per-participant activity
    activity: Dict[str, Dict[str, Any]] = defaultdict(lambda: {"asks": [], "commits": [], "messages": 0})
    action_items: List[str] = []
    decisions: List[str] = []

    for m in messages:
        sender = m.get("sender_name") or participants.get(m["sender_wa_id"], m["sender_wa_id"])
        text = m["text"]
        activity[sender]["messages"] += 1
        lower = text.lower()

        # Simple extraction
        if any(w in lower for w in ("please", "kindly", "can you", "could you", "need you to", "request")):
            activity[sender]["asks"].append(_clean(text))
            action_items.append(f"{sender} requested: {_clean(text)}")

        if any(w in lower for w in ("i will", "i'll", "i shall", "going to", "will send", "will share", "will prepare")):
            activity[sender]["commits"].append(_clean(text))
            action_items.append(f"{sender} committed: {_clean(text)}")

        if any(w in lower for w in ("decided", "agreed", "approved", "we will go with", "final decision")):
            decisions.append(f"{sender}: {_clean(text)}")

    # Build summary
    total_msgs = len(messages)
    unique_senders = len(activity)
    first_ts = messages[0]["timestamp"]
    last_ts = messages[-1]["timestamp"]

    summary_parts = [
        f"Conversation in group '{group['group_name']}' spanning {first_ts} to {last_ts}.",
        f"{total_msgs} messages from {unique_senders} participants.",
    ]

    # Highlight key themes
    themes = []
    all_text = " ".join(m["text"].lower() for m in messages)
    if any(w in all_text for w in ("site", "construction", "material", "delivery")):
        themes.append("site / construction coordination")
    if any(w in all_text for w in ("sales", "order", "client", "deal", "quotation")):
        themes.append("sales / commercial discussion")
    if any(w in all_text for w in ("invoice", "payment", "account")):
        themes.append("accounts / billing")
    if themes:
        summary_parts.append("Main themes: " + ", ".join(themes) + ".")

    if decisions:
        summary_parts.append(f"{len(decisions)} decision(s) recorded.")
    if action_items:
        summary_parts.append(f"{len(action_items)} action item(s) identified.")

    participant_activity = []
    for name, act in activity.items():
        participant_activity.append(
            {
                "name": name,
                "message_count": act["messages"],
                "asks": act["asks"][:5],  # limit noise
                "commits": act["commits"][:5],
            }
        )

    return {
        "summary": " ".join(summary_parts),
        "participant_activity": participant_activity,
        "action_items": action_items[:15],
        "decisions": decisions[:10],
    }