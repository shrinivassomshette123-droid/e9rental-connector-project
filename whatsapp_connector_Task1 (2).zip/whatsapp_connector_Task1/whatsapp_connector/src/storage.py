"""
In-memory + JSON persistence store for WhatsApp group data.
Only selected groups are ever stored.
"""

from __future__ import annotations
import json
import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
OUTPUT_PATH = BASE_DIR / "outputs" / "whatsapp_output.json"
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)


class GroupStore:
    def __init__(self) -> None:
        self._groups: Dict[str, Dict[str, Any]] = {}
        self._load_selected_config()

    def _load_selected_config(self) -> None:
        cfg_path = BASE_DIR / "config" / "selected_groups.json"
        with open(cfg_path, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        self.selected: Dict[str, str] = {
            g["group_id"]: g["group_name"] for g in cfg["selected_groups"]
        }

    def is_selected(self, group_id: str) -> bool:
        return group_id in self.selected

    def ensure_group(self, group_id: str, group_name: Optional[str] = None) -> None:
        if group_id not in self._groups:
            self._groups[group_id] = {
                "group_id": group_id,
                "group_name": group_name or self.selected.get(group_id, "Unknown Group"),
                "participants": {},
                "messages": [],
                "interpretation": None,
            }
        elif group_name:
            self._groups[group_id]["group_name"] = group_name

    def upsert_participant(self, group_id: str, wa_id: str, name: Optional[str] = None) -> None:
        if not self.is_selected(group_id):
            return
        self.ensure_group(group_id)
        participants = self._groups[group_id]["participants"]
        if wa_id not in participants:
            participants[wa_id] = {"wa_id": wa_id, "name": name or wa_id}
        elif name and participants[wa_id]["name"] == wa_id:
            participants[wa_id]["name"] = name

    def add_message(
        self,
        group_id: str,
        message_id: str,
        sender_wa_id: str,
        sender_name: Optional[str],
        text: str,
        timestamp: str,
    ) -> None:
        if not self.is_selected(group_id):
            return
        self.ensure_group(group_id)
        self.upsert_participant(group_id, sender_wa_id, sender_name)

        # Deduplicate by message_id
        existing_ids = {m["message_id"] for m in self._groups[group_id]["messages"]}
        if message_id in existing_ids:
            return

        self._groups[group_id]["messages"].append(
            {
                "message_id": message_id,
                "sender_wa_id": sender_wa_id,
                "sender_name": sender_name or sender_wa_id,
                "text": text,
                "timestamp": timestamp,
            }
        )
        # Keep chronological order
        self._groups[group_id]["messages"].sort(key=lambda m: m["timestamp"])

    def set_participants_list(self, group_id: str, participants: List[Dict[str, str]]) -> None:
        if not self.is_selected(group_id):
            return
        self.ensure_group(group_id)
        for p in participants:
            wa_id = p.get("wa_id") or p.get("id")
            name = p.get("name")
            if wa_id:
                self.upsert_participant(group_id, wa_id, name)

    def get_all(self) -> List[Dict[str, Any]]:
        result = []
        for gid, g in self._groups.items():
            if not self.is_selected(gid):
                continue
            result.append(
                {
                    "group_id": g["group_id"],
                    "group_name": g["group_name"],
                    "participants": list(g["participants"].values()),
                    "messages": g["messages"],
                    "interpretation": g["interpretation"],
                }
            )
        return result

    def set_interpretation(self, group_id: str, interpretation: Dict[str, Any]) -> None:
        if group_id in self._groups:
            self._groups[group_id]["interpretation"] = interpretation

    def save_output(self) -> str:
        data = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "groups": self.get_all(),
        }
        OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return str(OUTPUT_PATH)


# Singleton
store = GroupStore()